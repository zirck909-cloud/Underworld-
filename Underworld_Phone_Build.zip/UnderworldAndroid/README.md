# Underworld Android Starter

A Kotlin native Android 2D sandbox-survival starter project.

## Included
- Landscape Android activity and Canvas game surface
- Seeded chunk-based procedural terrain
- Basic player physics and touch controls
- Item registry and stack-based inventory
- Crafting recipes and ingredient validation
- Health/hunger model
- Basic enemy model
- Local player save repository
- Multiplayer message protocol scaffold

## Build
Open this folder in Android Studio with JDK 17 and Android SDK 35 installed.
Allow Gradle sync, then use Build > Build Bundle(s) / APK(s) > Build APK(s).

## Important status
This is an early source-code scaffold, not a finished game or a verified APK.
The multiplayer client transport is deliberately a placeholder. A real online
server, WebSocket transport, authentication, world-state replication, full save
format, polished UI, audio, art assets, tests and gameplay balancing remain to
be implemented and tested before release.
