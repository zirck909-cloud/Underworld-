package com.underworld.game.world

import kotlin.math.sin
import kotlin.random.Random

class WorldGenerator(private val seed: Int) {
    private val random = Random(seed)

    fun generateChunk(chunkX: Int, height: Int = 96): Chunk {
        val chunk = Chunk(chunkX, height)
        for (lx in 0 until Chunk.WIDTH) {
            val worldX = chunkX * Chunk.WIDTH + lx
            val surface = (25 + sin(worldX * 0.055) * 4 +
                sin(worldX * 0.13) * 2).toInt().coerceIn(12, height - 12)
            for (y in surface until height) {
                val tile = when {
                    y == surface -> Tile.GRASS
                    y < surface + 5 -> Tile.DIRT
                    else -> when {
                        y > surface + 12 && random.nextInt(100) < 4 -> Tile.COAL_ORE
                        y > surface + 18 && random.nextInt(100) < 2 -> Tile.COPPER_ORE
                        y > surface + 25 && random.nextInt(100) < 2 -> Tile.IRON_ORE
                        else -> Tile.STONE
                    }
                }
                chunk.set(lx, y, tile)
            }
        }
        // Small worm-like cave tunnels, kept below the surface.
        repeat(3) {
            var x = random.nextInt(Chunk.WIDTH)
            var y = random.nextInt(38, height - 3)
            repeat(random.nextInt(12, 35)) {
                chunk.set(x, y, Tile.AIR)
                x = (x + random.nextInt(-1, 2)).coerceIn(1, Chunk.WIDTH - 2)
                y = (y + random.nextInt(-1, 2)).coerceIn(30, height - 2)
            }
        }
        return chunk
    }
}
