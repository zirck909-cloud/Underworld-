package com.underworld.game.items

object ItemRegistry {
    val items = listOf(
        Item("dirt", "Dirt"), Item("stone", "Stone"),
        Item("wood", "Wood"), Item("coal", "Coal"),
        Item("copper_ore", "Copper Ore"), Item("iron_ore", "Iron Ore"),
        Item("leaves", "Leaves"), Item("workbench", "Workbench", 20),
        Item("wood_pickaxe", "Wooden Pickaxe", 1),
        Item("wood_sword", "Wooden Sword", 1)
    ).associateBy { it.id }

    fun get(id: String): Item? = items[id]
}
