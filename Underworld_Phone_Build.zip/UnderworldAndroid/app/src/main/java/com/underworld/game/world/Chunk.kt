package com.underworld.game.world

class Chunk(val chunkX: Int, val height: Int = 96) {
    companion object { const val WIDTH = 32 }
    private val tiles = Array(height) { Array(WIDTH) { Tile.AIR } }

    fun get(localX: Int, y: Int): Tile =
        if (localX in 0 until WIDTH && y in 0 until height) tiles[y][localX]
        else Tile.AIR

    fun set(localX: Int, y: Int, tile: Tile) {
        if (localX in 0 until WIDTH && y in 0 until height) tiles[y][localX] = tile
    }

    fun snapshot(): Array<Array<Tile>> = Array(height) { y -> tiles[y].clone() }
}
