package com.underworld.game.world

import kotlin.math.floor

class ChunkManager(seed: Int, private val height: Int = 96) {
    private val generator = WorldGenerator(seed)
    private val chunks = mutableMapOf<Int, Chunk>()

    fun getTile(worldX: Int, y: Int): Tile {
        if (y < 0) return Tile.AIR
        if (y >= height) return Tile.STONE
        val cx = floor(worldX.toDouble() / Chunk.WIDTH).toInt()
        val lx = Math.floorMod(worldX, Chunk.WIDTH)
        return getChunk(cx).get(lx, y)
    }

    fun setTile(worldX: Int, y: Int, tile: Tile) {
        if (y !in 0 until height) return
        val cx = floor(worldX.toDouble() / Chunk.WIDTH).toInt()
        val lx = Math.floorMod(worldX, Chunk.WIDTH)
        getChunk(cx).set(lx, y, tile)
    }

    fun getChunk(chunkX: Int): Chunk =
        chunks.getOrPut(chunkX) { generator.generateChunk(chunkX, height) }

    fun loadedChunks(): Set<Int> = chunks.keys.toSet()
}
