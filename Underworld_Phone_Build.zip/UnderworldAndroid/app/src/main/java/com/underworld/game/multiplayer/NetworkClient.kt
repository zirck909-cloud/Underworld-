package com.underworld.game.multiplayer

import java.net.URI
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import javax.net.ssl.SSLSocketFactory

/**
 * Minimal transport placeholder.
 * Production multiplayer should use a maintained WebSocket library,
 * TLS (wss://), authentication, reconnect handling and server validation.
 */
class NetworkClient {
    private val executor = Executors.newSingleThreadExecutor()
    private val connected = AtomicBoolean(false)

    fun isConnected(): Boolean = connected.get()

    fun connect(endpoint: String, onMessage: (String) -> Unit, onError: (Throwable) -> Unit) {
        executor.execute {
            try {
                val uri = URI(endpoint)
                require(uri.scheme == "wss" || uri.scheme == "ws")
                // Transport intentionally not implemented in this starter.
                // Do not treat this as a connected multiplayer client.
                throw UnsupportedOperationException(
                    "Install and configure a WebSocket transport before connecting."
                )
            } catch (t: Throwable) {
                connected.set(false)
                onError(t)
            }
        }
    }

    fun disconnect() { connected.set(false) }
}
