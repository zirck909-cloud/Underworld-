package com.underworld.game.world

enum class Tile(val color: Int, val solid: Boolean, val drops: String?) {
    AIR(0x00000000, false, null),
    GRASS(0xFF579B45.toInt(), true, "dirt"),
    DIRT(0xFF80502F.toInt(), true, "dirt"),
    STONE(0xFF777777.toInt(), true, "stone"),
    COAL_ORE(0xFF383838.toInt(), true, "coal"),
    COPPER_ORE(0xFFB87345.toInt(), true, "copper_ore"),
    IRON_ORE(0xFFB5A99A.toInt(), true, "iron_ore"),
    WOOD(0xFF9B652F.toInt(), true, "wood"),
    LEAVES(0xFF347A3A.toInt(), true, "leaves")
}
