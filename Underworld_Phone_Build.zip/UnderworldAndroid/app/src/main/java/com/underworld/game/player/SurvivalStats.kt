package com.underworld.game.player

data class SurvivalStats(
    var health: Float = 100f,
    var hunger: Float = 100f
) {
    fun damage(amount: Float) {
        health = (health - amount.coerceAtLeast(0f)).coerceAtLeast(0f)
    }

    fun feed(amount: Float) {
        hunger = (hunger + amount.coerceAtLeast(0f)).coerceAtMost(100f)
    }

    fun tick(seconds: Float) {
        hunger = (hunger - seconds * 0.12f).coerceAtLeast(0f)
        if (hunger <= 0f) damage(seconds * 0.8f)
        else if (hunger > 70f) health = (health + seconds * 0.15f).coerceAtMost(100f)
    }

    val isAlive: Boolean get() = health > 0f
}
