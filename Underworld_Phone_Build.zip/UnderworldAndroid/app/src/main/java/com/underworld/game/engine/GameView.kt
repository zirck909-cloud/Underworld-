package com.underworld.game.engine

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.MotionEvent
import com.underworld.game.player.Player
import com.underworld.game.world.ChunkManager
import com.underworld.game.world.Tile
import kotlin.concurrent.thread
import kotlin.math.floor

class GameView(context: Context) : SurfaceView(context), SurfaceHolder.Callback {
    private val paint = Paint().apply { isAntiAlias = false }
    private val world = ChunkManager(seed = 2026)
    private val player = Player()
    @Volatile private var running = false
    @Volatile private var paused = false
    @Volatile private var direction = 0f
    @Volatile private var jumpRequested = false
    private var loop: Thread? = null

    init {
        holder.addCallback(this)
        isFocusable = true
        player.y = 24f * 32f
    }

    fun resumeGame() { paused = false }
    fun pauseGame() { paused = true }

    override fun surfaceCreated(holder: SurfaceHolder) {
        running = true
        loop = thread(name = "UnderworldLoop") { runLoop() }
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        running = false
        loop?.join(1000)
        loop = null
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}

    private fun runLoop() {
        var last = System.nanoTime()
        while (running) {
            val now = System.nanoTime()
            val dt = ((now - last) / 1_000_000_000f).coerceIn(0f, 0.033f)
            last = now
            if (!paused) {
                if (jumpRequested) player.jump()
                jumpRequested = false
                player.update(world, direction, dt)
                renderFrame()
            }
            try { Thread.sleep(8) } catch (_: InterruptedException) { break }
        }
    }

    private fun renderFrame() {
        if (!holder.surface.isValid) return
        var canvas: Canvas? = null
        try {
            canvas = holder.lockCanvas()
            if (canvas != null) drawWorld(canvas)
        } finally {
            if (canvas != null) holder.unlockCanvasAndPost(canvas)
        }
    }

    private fun drawWorld(c: Canvas) {
        c.drawColor(Color.rgb(112, 185, 230))
        val ts = 32f
        val cameraX = (player.x - width / 2f).coerceAtLeast(0f)
        val cameraY = (player.y - height / 2f).coerceAtLeast(0f)
        val minX = floor(cameraX / ts).toInt()
        val maxX = floor((cameraX + width) / ts).toInt()
        val minY = floor(cameraY / ts).toInt()
        val maxY = floor((cameraY + height) / ts).toInt()

        for (x in minX..maxX) {
            for (y in minY..maxY) {
                val tile = world.getTile(x, y)
                if (tile == Tile.AIR) continue
                paint.color = tile.color
                val sx = x * ts - cameraX
                val sy = y * ts - cameraY
                c.drawRect(sx, sy, sx + ts, sy + ts, paint)
            }
        }

        paint.color = Color.rgb(190, 65, 55)
        c.drawRect(
            player.x - cameraX, player.y - cameraY,
            player.x - cameraX + player.width,
            player.y - cameraY + player.height, paint
        )

        paint.color = Color.argb(170, 25, 25, 30)
        c.drawRoundRect(20f, height - 85f, 165f, height - 20f, 12f, 12f, paint)
        c.drawRoundRect(width - 155f, height - 85f, width - 20f, height - 20f, 12f, 12f, paint)
        paint.color = Color.WHITE
        paint.textSize = 25f
        c.drawText("◀     ▶", 35f, height - 43f, paint)
        c.drawText("JUMP", width - 125f, height - 43f, paint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN,
            MotionEvent.ACTION_MOVE -> {
                var move = 0f
                var jump = false
                for (i in 0 until event.pointerCount) {
                    val x = event.getX(i)
                    val y = event.getY(i)
                    if (y > height - 100f && x < 180f) {
                        move = if (x < 90f) -1f else 1f
                    }
                    if (y > height - 100f && x > width - 160f) jump = true
                }
                direction = move
                if (jump) jumpRequested = true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                direction = 0f
            }
        }
        return true
    }
}
