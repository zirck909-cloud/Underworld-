package com.underworld.game.crafting

import com.underworld.game.items.ItemRegistry
import com.underworld.game.player.Inventory

class CraftingSystem {
    fun craft(
        recipe: Recipe,
        inventory: Inventory,
        hasWorkbench: Boolean
    ): Boolean {
        if (recipe.requiresWorkbench && !hasWorkbench) return false
        if (recipe.ingredients.any { (id, count) -> inventory.count(id) < count }) return false
        val output = ItemRegistry.get(recipe.outputId) ?: return false

        // Check output capacity before consuming ingredients.
        val probe = Inventory(inventory.capacity)
        inventory.snapshot().filterNotNull().forEach { probe.add(it.item, it.count) }
        if (probe.add(output, recipe.outputCount) != 0) return false

        recipe.ingredients.forEach { (id, count) ->
            check(inventory.consume(id, count))
        }
        return inventory.add(output, recipe.outputCount) == 0
    }
}
