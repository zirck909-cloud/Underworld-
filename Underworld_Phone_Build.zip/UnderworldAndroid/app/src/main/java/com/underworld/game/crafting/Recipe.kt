package com.underworld.game.crafting

data class Recipe(
    val outputId: String,
    val outputCount: Int,
    val ingredients: Map<String, Int>,
    val requiresWorkbench: Boolean = false
)

object Recipes {
    val all = listOf(
        Recipe("workbench", 1, mapOf("wood" to 10)),
        Recipe("wood_pickaxe", 1, mapOf("wood" to 8, "stone" to 3), true),
        Recipe("wood_sword", 1, mapOf("wood" to 6), true)
    )
}
