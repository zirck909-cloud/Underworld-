package com.underworld.game.multiplayer

import org.json.JSONObject

sealed class ClientMessage {
    data class Join(val roomId: String, val playerName: String) : ClientMessage()
    data class Move(val x: Float, val y: Float) : ClientMessage()
    data class Chat(val text: String) : ClientMessage()
}

object NetworkProtocol {
    fun encode(message: ClientMessage): String {
        val json = JSONObject()
        when (message) {
            is ClientMessage.Join -> json.put("type", "join")
                .put("roomId", message.roomId).put("playerName", message.playerName)
            is ClientMessage.Move -> json.put("type", "move")
                .put("x", message.x).put("y", message.y)
            is ClientMessage.Chat -> json.put("type", "chat").put("text", message.text)
        }
        return json.toString()
    }
}
