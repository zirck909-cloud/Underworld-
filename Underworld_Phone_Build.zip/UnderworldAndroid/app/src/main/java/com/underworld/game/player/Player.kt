package com.underworld.game.player

import com.underworld.game.world.ChunkManager
import com.underworld.game.world.Chunk

class Player(var x: Float = 100f, var y: Float = 100f) {
    val width = 24f
    val height = 30f
    var velocityY = 0f
    var grounded = false
    var facing = 1
    val inventory = Inventory()
    val stats = SurvivalStats()

    fun update(world: ChunkManager, direction: Float, dt: Float) {
        val speed = 150f
        val dx = direction.coerceIn(-1f, 1f) * speed * dt
        if (!collides(world, x + dx, y)) x += dx
        if (direction != 0f) facing = if (direction > 0) 1 else -1

        velocityY = (velocityY + 900f * dt).coerceAtMost(600f)
        val dy = velocityY * dt
        if (!collides(world, x, y + dy)) {
            y += dy
            grounded = false
        } else {
            if (velocityY > 0) grounded = true
            velocityY = 0f
        }
        stats.tick(dt)
    }

    fun jump() {
        if (grounded) {
            velocityY = -360f
            grounded = false
        }
    }

    private fun collides(world: ChunkManager, px: Float, py: Float): Boolean {
        val left = kotlin.math.floor(px / 32f).toInt()
        val right = kotlin.math.floor((px + width - 1) / 32f).toInt()
        val top = kotlin.math.floor(py / 32f).toInt()
        val bottom = kotlin.math.floor((py + height - 1) / 32f).toInt()
        for (tx in left..right) for (ty in top..bottom) {
            if (world.getTile(tx, ty).solid) return true
        }
        return false
    }
}
