package com.underworld.game.player

import com.underworld.game.items.Item
import com.underworld.game.items.ItemStack

class Inventory(val capacity: Int = 30) {
    private val slots = MutableList<ItemStack?>(capacity) { null }

    @Synchronized fun add(item: Item, amount: Int): Int {
        var remaining = amount
        for (stack in slots.filterNotNull().filter { it.item.id == item.id }) {
            val moved = minOf(remaining, item.maxStack - stack.count)
            stack.count += moved
            remaining -= moved
            if (remaining == 0) return 0
        }
        for (i in slots.indices) {
            if (slots[i] == null) {
                val moved = minOf(remaining, item.maxStack)
                slots[i] = ItemStack(item, moved)
                remaining -= moved
                if (remaining == 0) return 0
            }
        }
        return remaining
    }

    @Synchronized fun count(id: String): Int =
        slots.filterNotNull().filter { it.item.id == id }.sumOf { it.count }

    @Synchronized fun consume(id: String, amount: Int): Boolean {
        if (amount <= 0 || count(id) < amount) return false
        var remaining = amount
        for (i in slots.indices) {
            val stack = slots[i] ?: continue
            if (stack.item.id != id) continue
            val used = minOf(remaining, stack.count)
            stack.count -= used
            remaining -= used
            if (stack.count == 0) slots[i] = null
            if (remaining == 0) break
        }
        return true
    }

    @Synchronized fun snapshot(): List<ItemStack?> =
        slots.map { it?.copy() }
}
