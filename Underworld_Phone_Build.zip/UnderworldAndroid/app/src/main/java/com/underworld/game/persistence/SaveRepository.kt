package com.underworld.game.persistence

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class SaveRepository(context: Context) {
    private val prefs = context.getSharedPreferences("underworld_save", Context.MODE_PRIVATE)

    fun savePlayer(worldSeed: Int, x: Float, y: Float, health: Float, hunger: Float) {
        val json = JSONObject()
            .put("worldSeed", worldSeed)
            .put("x", x.toDouble())
            .put("y", y.toDouble())
            .put("health", health.toDouble())
            .put("hunger", hunger.toDouble())
        prefs.edit().putString("player_save", json.toString()).apply()
    }

    fun loadPlayer(): JSONObject? =
        prefs.getString("player_save", null)?.let {
            runCatching { JSONObject(it) }.getOrNull()
        }

    fun saveInventory(itemIds: List<String>, counts: List<Int>) {
        val array = JSONArray()
        itemIds.zip(counts).forEach { (id, count) ->
            array.put(JSONObject().put("id", id).put("count", count))
        }
        prefs.edit().putString("inventory", array.toString()).apply()
    }

    fun loadInventory(): JSONArray =
        runCatching {
            JSONArray(prefs.getString("inventory", "[]"))
        }.getOrDefault(JSONArray())
}
