package com.underworld.game.enemies

data class Enemy(
    var x: Float,
    var y: Float,
    var health: Float = 30f,
    var direction: Float = 1f
) {
    fun update(targetX: Float, dt: Float) {
        direction = if (targetX >= x) 1f else -1f
        x += direction * 45f * dt
    }

    fun damage(amount: Float) { health = (health - amount).coerceAtLeast(0f) }
    val alive: Boolean get() = health > 0f
}
