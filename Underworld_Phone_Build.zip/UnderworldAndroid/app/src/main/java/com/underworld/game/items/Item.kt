package com.underworld.game.items

data class Item(val id: String, val displayName: String, val maxStack: Int = 99)

data class ItemStack(val item: Item, var count: Int) {
    init { require(count in 1..item.maxStack) }
}
