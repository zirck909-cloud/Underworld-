# Underworld multiplayer server

The Android project includes a protocol model, not a production network transport.
The server is intentionally a separate deployment target. Before public multiplayer,
implement authenticated WebSockets over TLS, authoritative movement validation,
rate limits, room ownership, persistence, moderation and reconnect handling.

Target room capacity: 8 players.
